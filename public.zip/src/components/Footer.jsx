const Footer = () => {
  return <div className="footer">Copyright © 2023 - AgentTaskflow</div>;
};

export default Footer;
