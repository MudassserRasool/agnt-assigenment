export const FeatureCards = [
  {
    icon: '/FeaturesUserIcon.svg',
    heading: 'User information',
    description:
      'Borem ipsum dolor sit amet consectetur. Turpis tristique nulla posuere et amet arcu dictum ultricies convallis.',
  },
  {
    icon: '/FeatureDealIcon.svg',
    heading: 'User information',
    description:
      'Borem ipsum dolor sit amet consectetur. Turpis tristique nulla posuere et amet arcu dictum ultricies convallis.',
  },
  {
    icon: '/FeaturePipeLineIcon.svg',
    heading: 'User information',
    description:
      'Borem ipsum dolor sit amet consectetur. Turpis tristique nulla posuere et amet arcu dictum ultricies convallis.',
  },
  {
    icon: '/FeatureDocumentationIcon.png',
    heading: 'User information',
    description:
      'Borem ipsum dolor sit amet consectetur. Turpis tristique nulla posuere et amet arcu dictum ultricies convallis.',
  },
  {
    icon: '/FeaturesUserIcon.svg',
    heading: 'User information',
    description:
      'Borem ipsum dolor sit amet consectetur. Turpis tristique nulla posuere et amet arcu dictum ultricies convallis.',
  },
  {
    icon: '/FeaturesUserIcon.svg',
    heading: 'User information',
    description:
      'Borem ipsum dolor sit amet consectetur. Turpis tristique nulla posuere et amet arcu dictum ultricies convallis.',
  },
  {
    icon: '/FeaturesUserIcon.svg',
    heading: 'User information',
    description:
      'Borem ipsum dolor sit amet consectetur. Turpis tristique nulla posuere et amet arcu dictum ultricies convallis.',
  },
  {
    icon: '/FeaturesUserIcon.svg',
    heading: 'User information',
    description:
      'Borem ipsum dolor sit amet consectetur. Turpis tristique nulla posuere et amet arcu dictum ultricies convallis.',
  },
];

export const productivityCardData = [
  {
    title: 'Intuitive Interface',
    imageSrc: '/FeatureDocumentationIcon.png',
    description:
      'Our drag-and-drop interface makes crafting flows a breeze. No coding required! Create workflows with a few clicks and watch your ideas come to life.',
  },
  {
    title: 'Intuitive Interface',
    imageSrc: '/FeatureDocumentationIcon.png',
    description:
      'Our drag-and-drop interface makes crafting flows a breeze. No coding required! Create workflows with a few clicks and watch your ideas come to life.',
  },
  {
    title: 'Intuitive Interface',
    imageSrc: '/FeatureDocumentationIcon.png',
    description:
      'Our drag-and-drop interface makes crafting flows a breeze. No coding required! Create workflows with a few clicks and watch your ideas come to life.',
  },
];
